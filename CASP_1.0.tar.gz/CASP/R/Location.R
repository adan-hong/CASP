#' @title Location
#'
#' @description False positives can be estimated by combining the ratio of the calculation results of the A and B functions at the same time
#'
#' @details Be careful to keep pvalue and matrix in the same order
#'
#' @param pvalue pvalue is come from Gene differential expression analysis
#' @param matrix matrix is Pearson matrix
#' @param threshold threshold represents the degree of influence of the two genes, which is regarded as non-negligible
#' @return a dataframe
#' @export
#'
Location<-function(pvalue,matrix,threshold=0.05){
  print("Do the frist calculation")
  expdata1<-FollowTreat(pvalue,matrix,threshold=threshold)
  print("Do the reverse calculation")
  expdata2<-AntiFollowTreat(pvalue,matrix,threshold=threshold)
  Contribution<-data.frame(expdata1,AntiSumPearson=expdata2[,3])
  ratio<-Contribution[,4]/Contribution[,5]
  Contribution<-data.frame(Contribution,Ratio=ratio)
  return(Contribution)
}
