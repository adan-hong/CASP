CASPoint<-function(data){
  Falsepositive<-log(data$Ratio)
  Specificity<-data$SumPearson+data$AntiSumPearson
  dataname<-rownames(data)
  n<-nrow(data)
  test1<-Falsepositive[!is.infinite(Falsepositive)]
  meanline<-mean(test1)
  test2<-(Falsepositive-meanline)/sd(test1)
  meansp<-mean(Specificity)
  test3<-(Specificity-meansp)/sd(Specificity)
  Group<-rep('Back genes',nrow(data))
  index<-which(test2< -1.96)
  Group[index]<-'Shortlisted genes'
  dataplot<-data.frame(row.names = dataname,test2,test3,Group)


  p<-ggplot2::ggplot(dataplot,ggplot2::aes(x=test2,y=test3))+
    ggplot2::geom_point(alpha = 0.4,ggplot2::aes(shape=Group,color= Group))+
    ggplot2::labs(x='False Positive',y='Specificity')+
    ggplot2::geom_vline(xintercept = 0,linetype="dotted")+
    ggplot2::geom_vline(xintercept = -1.96,color='red' )+
    ggplot2::geom_vline(xintercept = 1.96,color='blue' )+
    ggplot2::geom_hline(yintercept = 0,linetype="dotted")+
    ggplot2::geom_hline(yintercept = -1.96,linetype="red")+
    ggplot2::geom_hline(yintercept = -1.96,linetype="blue")+
    ggplot2::theme_bw()

  return(p)
}
