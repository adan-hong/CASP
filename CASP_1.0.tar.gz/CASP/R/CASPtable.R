CASPtable<-function(data){
  Falsepositive<-log(data$Ratio)
  Specificity<-data$SumPearson+data$AntiSumPearson
  dataname<-rownames(data)
  n<-nrow(data)
  test1<-Falsepositive[!is.infinite(Falsepositive)]
  meanline<-mean(test1)
  test2<-(Falsepositive-meanline)/sd(test1)
  FAlsePP<-c()
  Direction<-c()
  meansp<-mean(Specificity)
  test3<-(Specificity-meansp)/sd(Specificity)
  SpePP<-c()
  Expression<-c()
  for (i in 1:n) {
    if(!is.infinite(test2[i])){
      if(test2[i]<0){
        FAlsePP<-append(FAlsePP,pnorm(test2[i])*2)
        Direction<-append(Direction,'Partial real')
      }else{
        FAlsePP<-append(FAlsePP,pnorm(-test2[i])*2)
        Direction<-append(Direction,'Partial false')
      }
    }else{
      FAlsePP<-append(FAlsePP,NA)
      if(data$SumPearson[i]>data$AntiSumPearson[i]){
        Direction<-append(Direction,'Partial false')
      }else{
        Direction<-append(Direction,'Partial real')
      }
    }
  }
  for (j in 1:n) {
    if(test3[j]<0){
        SpePP<-append(SpePP,pnorm(test3[j])*2)
        Expression<-append(Expression,'Partial specific-exp')
    }else{
        SpePP<-append(SpePP,pnorm(-test3[j])*2)
        Expression<-append(Expression,'Partial co-expression')
    }

  }
  expdata<-data.frame(SpePP,Expression,FAlsePP,Direction)
  return(expdata)
}

