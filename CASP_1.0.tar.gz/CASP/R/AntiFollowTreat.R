#' @title AntiFollowTreat
#'
#' @description AntiFollowTreat can estimate the probability of a true positive for each gene
#'
#' @details Be careful to keep pvalue and matrix in the same order
#'
#' @param pvalue pvalue is come from Gene differential expression analysis
#' @param matrix matrix is Pearson matrix
#' @param threshold threshold represents the degree of influence of the two genes, which is regarded as non-negligible
#' @return a dataframe
#' @export
#'
AntiFollowTreat<-function(pvalue,matrix,threshold=0.5){
  n<-1:nrow(pvalue)
  lnpvalue<- abs(log(pvalue))
  expdata<-data.frame(pvalue,lnpvalue,SumPearson=NA)
  colnames(expdata)<-c('Pvalue','LnPvalue','SumPearson')
  for(i in n){
    pA<-pvalue[i,]
    pearsons<-matrix[,i]
    index<-which(lnpvalue[n,]<lnpvalue[i,])
    sumlistp<-c()
    influence_coef<-c()
    for (j in index) {
      pB<-pvalue[j,]
      pearson<-pearsons[j]
      x<-(-(stats::qnorm(pA/2))+stats::qnorm(pB/2))*pearson/(1-pearson)
      X<- -(stats::qnorm(pB/2))-x
      pBB<-2*(stats::pnorm(-X))

      if((log(pB)-log(pBB))/log(pB)>threshold){
        sumlistp<-append(sumlistp,j)
      }
    }

    expdata[i,3]<-sum(pearsons[sumlistp])


    if(i%%200==0){
      print(paste('We have done',i,'genes'))
    }
    if(i==length(n)){
      print(paste('We have done',i,'genes'))
    }
  }
  return(expdata)
}
