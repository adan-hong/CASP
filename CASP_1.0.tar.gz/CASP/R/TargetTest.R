TargetTest<-function(pvalue,matrix,i){
  n<-1:nrow(pvalue)
  lnpvalue<- abs(log(pvalue))
  pA<-pvalue[i,]
  pearsons<-matrix[,i]
  index1<-which(lnpvalue[n,]>lnpvalue[i,])
  index2<-which(lnpvalue[n,]<lnpvalue[i,])
  expdata<-data.frame(pvalue,lnpvalue,proportion=NA)

  for (j in index1){
    pB<-pvalue[j,]
    pearson<-pearsons[j]
    x<-(-(stats::qnorm(pB/2))+stats::qnorm(pA/2))*pearson/(1-pearson)
    X<- -(stats::qnorm(pA/2))-x
    pAA<-2*(stats::pnorm(-X))
    expdata[j,3]<-(1-log(pAA)/log(pA))
  }
  for (k in index2){
    pB<-pvalue[k,]
    pearson<-pearsons[k]
    x<-(-(stats::qnorm(pA/2))+stats::qnorm(pB/2))*pearson/(1-pearson)
    X<- -(stats::qnorm(pB/2))-x
    pBB<-2*(stats::pnorm(-X))
    expdata[k,3]<-(log(pBB)/log(pB)-1)
  }
  colnames(expdata)<-c('pvalue','lnpvalue','proportion')
  expdata<-expdata[order(expdata[,3],decreasing = T),]
  return(expdata)
}
