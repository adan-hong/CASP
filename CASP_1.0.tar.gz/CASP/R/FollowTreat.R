#' @title FollowTreat
#'
#' @description FollowTreat can estimate the probability of a false positive for each gene
#'
#' @details Be careful to keep pvalue and matrix in the same order
#'
#' @param pvalue pvalue is come from Gene differential expression analysis
#' @param matrix matrix is Pearson matrix
#' @param threshold threshold represents the degree of influence of the two genes, which is regarded as non-negligible
#' @return a dataframe
#' @export
#'


FollowTreat<-function(pvalue,matrix,threshold=0.5){
  n<-1:nrow(pvalue)
  lnpvalue<- abs(log(pvalue))
  expdata<-data.frame(pvalue,lnpvalue,gselect=NA,sumgsP=NA)
  colnames(expdata)<-c('Pvalue','LnPvalue','CoverageRate','SumPearson')
  for(i in n){
    pA<-pvalue[i,]
    pearsons<-matrix[,i]
    index<-which(lnpvalue[n,]>lnpvalue[i,])
    sumlistp<-c()
    influence_coef<-c()
    for (j in index) {
      pB<-pvalue[j,]
      pearson<-pearsons[j]
      x<-(-(stats::qnorm(pB/2))+stats::qnorm(pA/2))*pearson/(1-pearson)
      X<- -(stats::qnorm(pA/2))-x
      pAA<-2*(stats::pnorm(-X))

      if((log(pA)-log(pAA))/log(pA)>threshold){
        sumlistp<-append(sumlistp,j)
      }
    }

    expdata[i,4]<-sum(pearsons[sumlistp])
    if(sum(pearsons[sumlistp])>4.6){
      expdata[i,3]<-'Coverage>99%'}else{
        expdata[i,3]<-'Coverage<99%'}

    if(i%%200==0){
      print(paste('We have done',i,'genes'))
    }
    if(i==length(n)){
      print(paste('We have done',i,'genes'))
    }
  }
  return(expdata)
}
